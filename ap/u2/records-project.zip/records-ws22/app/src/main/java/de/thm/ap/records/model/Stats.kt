package de.thm.ap.records.model

class Stats(val records: List<Record>) {

  val sumCrp = 0
  val crpToEnd = 0
  val sumHalfWeighted = 0
  val averageMark = 0

  init {
    TODO("Stats not calculated yet!")
  }

  override fun toString(): String {
    return "Stats(sumCrp=$sumCrp, crpToEnd=$crpToEnd, sumHalfWeighted=$sumHalfWeighted, averageMark=$averageMark)"
  }


}