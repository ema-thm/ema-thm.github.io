package de.thm.ap.records.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Info
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import de.thm.ap.records.R
import de.thm.ap.records.data.RecordDAO
import de.thm.ap.records.model.Record
import de.thm.ap.records.ui.theme.RecordsTheme
import java.util.*

@Composable
fun RecordFormScreen(
  navController: NavController,
  initRecord: Record,
  isEditMode: Boolean,
) {
  var record by remember { mutableStateOf(initRecord) }
  var yearDropdownExpanded by remember { mutableStateOf(false) }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { TODO() },
        navigationIcon = {
          IconButton(onClick = { navController.navigateUp() }) {
            Icon(
              imageVector = Icons.Filled.ArrowBack,
              contentDescription = "Up"
            )
          }
        }
      )
    }
  ) { innerPadding ->
    val errorMsgs = remember { mutableStateMapOf<String, String>() }
    val focusRequester = remember { FocusRequester() }
    val ctx = LocalContext.current
    val spacerHeight = 20.dp

    Column(
      Modifier
        .fillMaxWidth()
        .padding(innerPadding)
        .padding(16.dp),
    ) {

      if (!isEditMode) {
        LaunchedEffect(Unit) {focusRequester.requestFocus()}
      }

      MyTextField(
        value = record.moduleNum ?: "",
        onValueChange = { record = record.copy(moduleNum = it) },
        errorText = errorMsgs["moduleNum"] ?: "",
        maxLength = 10,
        showMaxLength = true,
        label = { Text(stringResource(id = R.string.module_num)) },
        modifier = Modifier
          .fillMaxWidth()
          .focusRequester(focusRequester)
      )

      MyTextField(
        value = record.moduleName ?: "",
        onValueChange = { record = record.copy(moduleName = it) },
        errorText = errorMsgs["moduleName"] ?: "",
        maxLength = 100,
        showMaxLength = true,
        label = { Text(stringResource(id = R.string.module_name)) },
        modifier = Modifier.fillMaxWidth()
      )

      Row(
        modifier = Modifier.fillMaxWidth(),
      ) {
        MyTextField(
          value = "${record.crp ?: ""}",
          onValueChange = { record = record.copy(crp = it.toIntOrNull()) },
          errorText = errorMsgs["crp"] ?: "",
          maxLength = 2,
          label = { Text(stringResource(id = R.string.crp)) },
          modifier = Modifier.weight(1f),
          keyboardOptions = KeyboardOptions.Default.copy(
            imeAction = ImeAction.Done,
            keyboardType = KeyboardType.Number
          ),
        )

        Spacer(modifier = Modifier.width(16.dp))

        MyTextField(
          value = "${record.mark ?: ""}",
          onValueChange = { record = record.copy(mark = it.take(3).toIntOrNull()) },
          errorText = errorMsgs["mark"] ?: "",
          maxLength = 3,
          label = { Text(stringResource(id = R.string.mark_in_percent)) },
          modifier = Modifier.weight(1f),
          keyboardOptions = KeyboardOptions.Default.copy(
            imeAction = ImeAction.Done,
            keyboardType = KeyboardType.Number
          ),
          keyboardActions = KeyboardActions.Default
        )
      }

      Spacer(modifier = Modifier.height(spacerHeight))

      Row(
        modifier = Modifier.fillMaxWidth(),
      ) {
        TextField(
          value = record.year.toString(),
          onValueChange = { },
          trailingIcon = {
            IconButton(onClick = { yearDropdownExpanded = true }) {
              Icon(
                imageVector = Icons.Default.ArrowDropDown,
                contentDescription = "Select year",
              )
            }
          },
          readOnly = true,
          modifier = Modifier
            .weight(1f)
            .clickable(onClick = {
              yearDropdownExpanded = true
            })
        )

        DropdownMenu(
          expanded = yearDropdownExpanded,
          onDismissRequest = { yearDropdownExpanded = false },
          modifier = Modifier.fillMaxWidth()
        ) {
          getYears().forEach { year ->
            DropdownMenuItem(
              onClick = {
                record = record.copy(year = year)
                yearDropdownExpanded = false
              }) {
              Text(text = year.toString())
            }

          }

        }
        Spacer(Modifier.width(4.dp))
        Row(
          modifier = Modifier.weight(1f),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.End
        ) {
          Text(text = stringResource(id = R.string.summer_term))
          Checkbox(
            checked = record.isSummerTerm,
            onCheckedChange = { record = record.copy(isSummerTerm = it) }
          )
        }

      }
      Spacer(modifier = Modifier.height(spacerHeight))

      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.End,
        modifier = Modifier.fillMaxWidth()
      ) {
        Text(text = stringResource(id = R.string.half_weighted_record))
        Checkbox(
          modifier = Modifier.padding(0.dp),
          checked = record.isHalfWeighted,
          onCheckedChange = { record = record.copy(isHalfWeighted = it) }
        )
      }


      Spacer(modifier = Modifier.height(spacerHeight))
      Button(
        onClick = {
          errorMsgs.clear()

          TODO("Record validation not implemented yet!")

          if (errorMsgs.isEmpty()) {
            if (isEditMode) {
              RecordDAO.get(ctx).update(record)
            } else {
              RecordDAO.get(ctx).persist(record)
            }
            navController.navigateUp()
          }

        },
        modifier = Modifier.fillMaxWidth(),
      ) {
        Text(stringResource(id = R.string.save))
      }
      Spacer(modifier = Modifier.height(spacerHeight))
      Text(text = stringResource(id = R.string.required))
    }
  }
}

@Composable
fun ErrorText(errorText: String): Unit {
  Text(
    text = errorText,
    color = MaterialTheme.colors.error,
    style = MaterialTheme.typography.caption,
    modifier = Modifier.padding(start = 16.dp, bottom = 8.dp)
  )
}

@Composable
fun MyTextField(
  value: String,
  onValueChange: (String) -> Unit,
  errorText: String,
  modifier: Modifier = Modifier,
  maxLength: Int = Int.MAX_VALUE,
  showMaxLength: Boolean = false,
  label: @Composable (() -> Unit)? = null,
  keyboardActions: KeyboardActions = KeyboardActions(),
  keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
) {
  val focusManager = LocalFocusManager.current

  Column(modifier = modifier.fillMaxWidth()) {
    TextField(
      value = value,
      onValueChange = {
        onValueChange(
          it.take(maxLength).trim().replace("[\n\t]".toRegex(), "")
        )
      },
      label = label,
      trailingIcon = {
        if (errorText.isNotBlank()) {
          Icon(Icons.Filled.Info, "Error", tint = MaterialTheme.colors.error)
        }
      },
      singleLine = true,
      maxLines = 1,
      modifier = Modifier.fillMaxWidth(),
      isError = errorText.isNotBlank(),
      keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() }),
      keyboardOptions = keyboardOptions.copy(
        imeAction = ImeAction.Done,
      ),
    )
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      if (errorText.isNotBlank()) {
        ErrorText(errorText)
      } else {
        Spacer(modifier = Modifier.height(24.dp))
      }

      if (showMaxLength) {
        Text(
          text = "${value.length} / $maxLength",
          textAlign = TextAlign.End,
          style = MaterialTheme.typography.caption,
          modifier = Modifier
            .padding(end = 16.dp)
        )
      }
    }
  }
}

@Preview(widthDp = 320)
@Composable
fun MyTextFieldPreview() {
  RecordsTheme() {
    Column() {
      MyTextField(
        value = "Test value 123",
        onValueChange = {},
        errorText = "",
        maxLength = 100,
        label = { Text(stringResource(id = R.string.module_name)) },
        modifier = Modifier.fillMaxWidth()
      )
    }

  }
}

/**
 * @return list of last 10 years.
 */
fun getYears(): List<Int> = TODO()