package de.thm.ap.records

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.navigation.NavBackStackEntry
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import de.thm.ap.records.model.Record
import de.thm.ap.records.data.RecordDAO
import de.thm.ap.records.ui.screens.RecordFormScreen
import de.thm.ap.records.ui.screens.RecordsScreen
import de.thm.ap.records.ui.theme.RecordsTheme

class MainActivity : ComponentActivity() {

  private val recordDao by lazy { RecordDAO.get(this) }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)

    setContent {
      RecordsTheme {
        val navController = rememberNavController()

        NavHost(navController = navController, startDestination = "records") {
          // NavGraphBuilder
          composable("records") {
            RecordsScreen(
              records = recordDao.findAll(),
              onAddRecordClick = { navController.navigate("recordForm") },
              onRecordClick = { navController.navigate("recordForm?recordId=${it.id}") },
            )
          }

          composable(
            "recordForm?recordId={recordId}",
            arguments = listOf(navArgument("recordId") {
              defaultValue = -1
              type = NavType.IntType
            })
          )
          { backStackEntry: NavBackStackEntry ->

            var record = Record()
            var isEditMode = false
            val recordId = backStackEntry.arguments?.getInt("recordId") ?: -1
            if (recordId != -1)
              recordDao.findById(recordId)?.let {
                record = it
                isEditMode = true
              }
            RecordFormScreen(
              navController = navController,
              initRecord = record,
              isEditMode = isEditMode,
            )

          }
        }
      }
    }
  }
}