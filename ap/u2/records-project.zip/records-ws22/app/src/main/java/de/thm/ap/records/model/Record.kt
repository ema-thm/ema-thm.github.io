package de.thm.ap.records.model

import java.io.Serializable
import java.util.*

data class Record(
  val id: Int? = null,
  val moduleNum: String? = null,
  val moduleName: String? = null,
  val year: Int? = Calendar.getInstance()[Calendar.YEAR],
  val isSummerTerm: Boolean = false,
  val isHalfWeighted: Boolean = false,
  val crp: Int? = null,
  val mark: Int? = null
) : Serializable {


  override fun toString(): String {
    return StringBuilder().apply {
      moduleName?.let { append("$it ") }
      moduleNum?.let { append("$it ") }
      append("(")
      mark?.let { append("$it% ") }
      append("$crp CrP")
      append(")")
    }.toString()
  }


}