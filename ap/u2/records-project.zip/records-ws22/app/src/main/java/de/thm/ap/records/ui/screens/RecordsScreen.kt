package de.thm.ap.records.ui.screens

import android.content.res.Configuration
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Devices
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import de.thm.ap.records.R
import de.thm.ap.records.data.RecordDAO
import de.thm.ap.records.model.Record
import de.thm.ap.records.model.Stats
import de.thm.ap.records.ui.theme.RecordsTheme


@Composable
fun RecordsScreen(
  records: List<Record>,
  onAddRecordClick: () -> Unit,
  onRecordClick: (Record) -> Unit,
) {
  var showDialog by remember { mutableStateOf(false) }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text(stringResource(R.string.app_name)) },
        actions = {
          IconButton(
            onClick = onAddRecordClick
          ) {
            Icon(
              imageVector = Icons.Default.Add,
              contentDescription = "Add record"
            )
          }
          IconButton(
            onClick = {
              showDialog = true
            }
          ) {
            Icon(
              painter = painterResource(R.drawable.ic_bar_chart_24),
              contentDescription = "Show stats"
            )
          }
        }
      )
    }
  ) { innerPadding ->

    if (showDialog) {
      StatsDialog(Stats(records)) { showDialog = false }
    }

    if (records.isEmpty()) {
      Text(
        text = stringResource(id = R.string.no_records),
        style = MaterialTheme.typography.h5,
        modifier = Modifier.padding(16.dp)
      )
    } else {
      LazyColumn(
        contentPadding = innerPadding
      ) {
        items(records) { record ->
          RecordListItem(record = record, onRecordClick)
          Divider()
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterialApi::class)
@Composable
fun RecordListItem(
  record: Record,
  onRecordClick: (Record) -> Unit,
) {
  ListItem(
    modifier = Modifier.clickable {
      onRecordClick(record)
    }
  ) {
    Text(
      text = record.toString(),
      maxLines = 1,
      overflow = TextOverflow.Ellipsis
    )
  }
}

@Composable
fun StatsDialog(stats: Stats, onClose: () -> Unit) {
  TODO("Stats dialog not implemented yet!")
}

@Preview
@Composable
fun StatsDialogPreview() {
  RecordsTheme {
    StatsDialog(Stats(RecordDAO.createTestRecords(1)), {})
  }
}

@Preview
@Preview(
  "Records screen (dark)",
  uiMode = Configuration.UI_MODE_NIGHT_YES,
  device = Devices.PHONE,
)
@Composable
fun RecordsScreenPreview() {
  RecordsTheme {
    RecordsScreen(records = RecordDAO.createTestRecords(1), {}, {})
  }
}